#### Об'єкти

1. [Об'єкти на Learn.js](https://uk.javascript.info/object)
2. [Основи об'єктів в js. Стаття на MDN](https://developer.mozilla.org/ru/docs/Learn/JavaScript/Objects/Basics)
3. [Робота с об'єктами](https://developer.mozilla.org/ru/docs/Web/JavaScript/Guide/Working_with_Objects). Это продвинутая статья, в которой упоминаются материалы из последующих уроков. Прочитайте до конца, даже если мало понятно. Дальше будет проще усваиваться