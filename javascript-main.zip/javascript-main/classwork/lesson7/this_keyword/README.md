#### Ключове слово this

1. [Методи об'єкта, this](https://uk.javascript.info/object-methods)
2. [Ключевое слово this в JavaScript для початківців](https://habr.com/ru/company/ruvds/blog/419371/) Може знадобитись VPN.
3. [Детально про те, як працює this в JavaScript](https://medium.com/@stasonmars/%D0%BF%D0%BE%D0%B4%D1%80%D0%BE%D0%B1%D0%BD%D0%BE-%D0%BE-%D1%82%D0%BE%D0%BC-%D0%BA%D0%B0%D0%BA-%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%B0%D0%B5%D1%82-this-%D0%B2-javascript-a13b4b6ec9ac)

