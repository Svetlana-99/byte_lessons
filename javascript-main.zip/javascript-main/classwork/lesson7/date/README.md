#### Об`єкт дати

1. [Дата та час на Learn.js](https://uk.javascript.info/date)
2. [Об'єкт дати. MDN](https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Global_Objects/Date)
4. [Робота з датою та часом в JavaScript](https://itchief.ru/javascript/date)
