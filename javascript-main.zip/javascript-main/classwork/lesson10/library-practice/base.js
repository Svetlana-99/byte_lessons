const actionButton = document.querySelector("button");
actionButton.addEventListener("click", library);

const books = [
  { id: 1, author: "A", name: "B", isReading: false },
  { id: 2, author: "A", name: "C", isReading: false },
  { id: 3, author: "A", name: "D", isReading: false },
  { id: 4, author: "A", name: "E", isReading: false },
  { id: 5, author: "A", name: "F", isReading: false },
];

function library() {
  
}