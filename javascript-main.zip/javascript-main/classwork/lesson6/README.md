#### Числа

1. [Числа](https://uk.javascript.info/number)
2. [Методи чисел (посилання на розбір кожного)](https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Global_Objects/Number)
3. [Вбудований об'єкт Math та його методи](https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Global_Objects/Math)

#### Строки

1. [Строки](https://uk.javascript.info/string)
2. [Робота с текстом в JavaScript](https://developer.mozilla.org/ru/docs/Learn/JavaScript/First_steps/Strings)
3. [Корисні строкові методи](https://developer.mozilla.org/ru/docs/Learn/JavaScript/First_steps/Useful_string_methods)
4. [Шпаргалка по всім методам строк з прикладами](https://tproger.ru/articles/metody-strok-v-javascript-shpargalka-dlja-nachinajushhih/)


