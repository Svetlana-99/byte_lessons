### Атрибути

[Атрибути та властивості](https://uk.javascript.info/dom-attributes-and-properties)

[Робота з атрибутами та властивостями елементів в JavaScript](https://itchief.ru/javascript/attributes-and-properties)

### Форми

[Елементи форми](https://uk.javascript.info/form-elements)

[Події елементів форми](https://uk.javascript.info/events-change-input)

[Відправка форми через JavaScript](https://uk.javascript.info/forms-submit)
