[Класи. MDN](https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Classes)

[Клас: базовий синтаксис](https://uk.javascript.info/class)

[Статичні властивості та методи](https://uk.javascript.info/static-properties-methods)

[Гетери і сетери властивостей](https://uk.javascript.info/property-accessors)