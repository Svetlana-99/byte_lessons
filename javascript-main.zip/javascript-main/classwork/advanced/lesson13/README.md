### Події в JavaScript.
[Вступ до подій браузера](https://uk.javascript.info/introduction-browser-events)

[Вступ до подій, стаття на MDN](https://developer.mozilla.org/ru/docs/Learn/JavaScript/Building_blocks/Events)

[Об'єкт події (Event)](https://learn.javascript.ru/obtaining-event-object)

[Про метод addEventListener](https://developer.mozilla.org/ru/docs/Web/API/EventTarget/addEventListener)

[Список подій в Javascript](https://www.w3schools.com/tags/ref_eventattributes.asp)

[Mouse Event](https://developer.mozilla.org/ru/docs/Web/API/MouseEvent)

[Події руху миші](https://learn.javascript.ru/mousemove-mouseover-mouseout-mouseenter-mouseleave)

[Основи подій миші](https://uk.javascript.info/mouse-events-basics)

[Keyboard Event](https://developer.mozilla.org/ru/docs/Web/API/KeyboardEvent)

[Основи подій клавіатури](https://uk.javascript.info/keyboard-events)
