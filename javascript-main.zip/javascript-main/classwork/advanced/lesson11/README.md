### DOM. Браузерне середовище.
[Що таке Об'єктна Модель Документа (DOM)?](https://developer.mozilla.org/ru/docs/Web/API/Document_Object_Model/Introduction)

[Браузерне середовище, специфікації](https://uk.javascript.info/browser-environment)

[DOM Дерево](https://uk.javascript.info/dom-nodes)

[У чому різниця між вузлом та елементом DOM?](https://habr.com/ru/company/ruvds/blog/539096/) Може знадобитись VPN.

[Навігація по DOM-елементам](https://uk.javascript.info/dom-navigation)

[DOM Selectors Explained](https://blog.bitsrc.io/dom-selectors-explained-70260049aaf0)

[HTMLCollection vs NodeList](https://medium.com/@layne_celeste/htmlcollection-vs-nodelist-4b83e3a4fb4b)

### Редагування документа

[Внесення змін в документ](https://uk.javascript.info/modifying-document)

[Різниця innerText та innerHTML. Прочитайте перші 4 відповіді.](https://stackoverflow.com/questions/19030742/difference-between-innertext-innerhtml-and-value)
