### XHR. Робота з сервером

[Клієнт-серверна архітектура. Як все влаштовано простою мовою](https://habr.com/ru/post/495698/) Може знадобитись VPN

[XMLHttpRequest - Learn.js](https://uk.javascript.info/xmlhttprequest)

[Використання XMLHttpRequest. Всі можливості, детально на MDN](https://developer.mozilla.org/ru/docs/Web/API/XMLHttpRequest/Using_XMLHttpRequest)

[Коди відповіді HTTP](https://developer.mozilla.org/ru/docs/Web/HTTP/Status)

[Коди відповідей у зображеннях (з котиками)](https://http.cat/)

[Методи HTTP запиту](https://developer.mozilla.org/ru/docs/Web/HTTP/Methods)

[Типи (методи) HTTP-запитів та філософія REST](https://habr.com/ru/post/50147/) Може знадобитись VPN
