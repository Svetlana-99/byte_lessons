### Функції-конструктори. Ключове слово new.
[Конструктори об'єктів](https://metanit.com/web/javascript/4.5.php)

[Конструктори, створення об'єктів через "new"](https://uk.javascript.info/constructor-new)

[Оператор new](https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Operators/new)

### This. Call, bind, apply
[Function.prototype.bind()](https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Global_Objects/Function/bind)

[Bind, Call та Apply в JavaScript. Цікавий приклад коду для більш глибокого розуміння](https://habr.com/ru/post/199456/) Може знадобитись VPN

### Prototype. Prototype Inheritance

[(Нe) все в JavaScript — об'єкт](https://medium.com/devschacht/daniel-li-not-everything-in-javascript-is-an-object-82fe5026e1a2)

[Успадкування через прототипи](https://uk.javascript.info/prototype-inheritance)

[Function.prototype](https://uk.javascript.info/function-prototype)

[Вбудовані прототипи](https://uk.javascript.info/native-prototypes)

[Методи прототипів, об'єкти без властивості __proto__](https://uk.javascript.info/prototype-methods)

### ООП в js.

[JavaScript: ООП, функціональний стиль](https://habr.com/ru/sandbox/123183/)

[Об'єктно-орієнтований JavaScript для початківців](https://developer.mozilla.org/ru/docs/Learn/JavaScript/Objects/Object-oriented_JS)

### Prototype. Успадкування та розширення класів.
[Успадкування в JavaScript](https://developer.mozilla.org/ru/docs/Learn/JavaScript/Objects/Inheritance)

[Метод Object.create()](https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Global_Objects/Object/create)
