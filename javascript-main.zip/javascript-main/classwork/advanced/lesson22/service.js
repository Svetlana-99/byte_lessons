import { divide } from "./lib.js";

const add = (a) => a + 10;

export const result = divide(10, 2);

export default 20;
