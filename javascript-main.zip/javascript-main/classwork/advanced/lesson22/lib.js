const add = (a, b) => a + b;

const divide = (a, b) => a / b;

const power = (a, pow) => a ** pow;

export {
  add, divide, power
}

const test = (x) => {
  return x + 10
}

export default test;