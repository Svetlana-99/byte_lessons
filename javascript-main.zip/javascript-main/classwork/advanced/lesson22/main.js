import * as helpers from "./lib.js";
import func from './lib.js'
import number, { result } from "./service.js";
// import number from './service.js'

console.log(`number`, number);
// JS Modules

console.log(`helpers`, helpers);

const y = func(20);
console.log(`y`, y)

const res = helpers.divide(1, 2);
console.log(`res`, res);

// console.log(`result`, result)

// imports / exports

// - named
// - default
