### Fetch

[Fetch. Learn JS](https://learn.javascript.ru/fetch)

[Fetch API. MDN](https://developer.mozilla.org/ru/docs/Web/API/Fetch_API)

[Fetch vs XMLHttpRequest](https://medium.com/beginners-guide-to-mobile-web-development/the-fetch-api-2c962591f5c)

### Async await

[Async/await. Learn JS](https://uk.javascript.info/async-await)

[Making asynchronous programming easier with async and await (RU)](https://developer.mozilla.org/ru/docs/Learn/JavaScript/Asynchronous/Async_await)

[Зрозуміють навіть діти: просте пояснення async/await та промісів в JavaScript](https://habr.com/ru/post/474726/) Може знадобитись VPN

### Promise.all()

[Promise.all і не тільки. Learn JS](https://uk.javascript.info/promise-api)

[Promise.all на MDN](https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Global_Objects/Promise/all)

### Error & try...catch

[Error, типи помилок](https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Global_Objects/Error)

[Обробка помилок в JS](https://developer.mozilla.org/ru/docs/Web/JavaScript/Guide/Control_flow_and_error_handling#%D0%B8%D0%BD%D1%81%D1%82%D1%80%D1%83%D0%BA%D1%86%D0%B8%D0%B8_%D0%BE%D0%B1%D1%80%D0%B0%D0%B1%D0%BE%D1%82%D0%BA%D0%B8_%D0%B8%D1%81%D0%BA%D0%BB%D1%8E%D1%87%D0%B5%D0%BD%D0%B8%D0%B9)

[Обробка помилок, "try..catch". Learn JS](https://uk.javascript.info/try-catch)

[try...catch, MDN](https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Statements/try...catch)

[Обробка помилок в JavaScript, хороша стаття](https://habr.com/ru/company/reksoft/blog/518050/) Може знадобитись VPN
