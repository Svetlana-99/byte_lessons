### Робота зі стилями в JS.
[Стилі та класи](https://uk.javascript.info/styles-and-classes)

[Управління класами та стилями елементів в JavaScript](https://itchief.ru/javascript/classes-and-styles)


### Координати та розміри елементів

[Координати](https://uk.javascript.info/coordinates)

[Розміри та прокрутка елементів](https://learn.javascript.ru/size-and-scroll)

[Про метод getBoundingClientRect()](https://developer.mozilla.org/ru/docs/Web/API/Element/getBoundingClientRect)
