### Деструктуризація. Rest & Spread оператори.

[Деструктурооване присвоєння (learn.js)](https://uk.javascript.info/destructuring-assignment)

[Деструктуроване присвоєння (MDN)](https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Operators/Destructuring_assignment)

[Залишкові параметри та оператор розширення (Rest & Spread)](https://learn.javascript.ru/rest-parameters-spread-operator)

[Rest parameters](https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Functions/Rest_parameters)

[Spread syntax(operator)](https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Operators/Spread_syntax)

### Регулярні вирази

[Все про регулярні вирази. Детальний розбір всіх спецсимволів](https://learn.javascript.ru/regular-expressions)

[Про регулярні вирази на MDN](https://developer.mozilla.org/ru/docs/Web/JavaScript/Guide/Regular_Expressions)

[Метод RegExp та методи рядків, у які інтегровані регулярні вирази](https://learn.javascript.ru/regexp-methods)

