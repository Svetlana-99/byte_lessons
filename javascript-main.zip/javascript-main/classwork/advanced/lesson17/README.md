### Таймери timeout та interval. Планування.

1. [Планування: setTimeout і setInterval](https://uk.javascript.info/settimeout-setinterval)
2. [Розуміння таймерів у JavaScript. ](https://medium.com/@stasonmars/%D0%BF%D0%BE%D0%BD%D0%B8%D0%BC%D0%B0%D0%BD%D0%B8%D0%B5-%D1%82%D0%B0%D0%B8%CC%86%D0%BC%D0%B5%D1%80%D0%BE%D0%B2-%D0%B2-javascript-callback-%D1%84%D1%83%D0%BD%D0%BA%D1%86%D0%B8%D0%B8-settimeout-setinterval-%D0%B8-requestanimationframe-f73c81cfdc9d)

### Promise
1. [Promise (основи)](https://uk.javascript.info/promise-basics)
2. [Теорія Promise](https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Global_Objects/Promise)
3. [Використання промісів](https://developer.mozilla.org/ru/docs/Web/JavaScript/Guide/Using_promises)

### Event Loop
1. [What the heck is the event loop anyway? | Philip Roberts | JSConf EU (доповідь)](https://www.youtube.com/watch?v=8aGhZQkoFbQ&ab_channel=JSConf)
2. [Подійний цикл (Event loop)](https://learn.javascript.ru/event-loop)
3. [Як влаштований Event Loop в JavaScript: паралельна модель і цикл подій](https://highload.today/kak-ustroen-event-loop-v-javascript-parallelnaya-model-i-tsikl-sobytij/)
4. [Пояснення роботи EventLoop в JavaScript](https://medium.com/devschacht/javascript-eventloop-explained-f2dcf84e36ee)
