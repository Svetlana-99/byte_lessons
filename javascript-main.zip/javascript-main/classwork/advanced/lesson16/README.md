### JSON

[Що таке JSON. Розгорнутий матеріал](https://habr.com/ru/post/554274/) Може знадобитись VPN
### localStorage, sessionStorage, cookies
[Cookies, document.cookie](https://uk.javascript.info/cookie)

[localStorage, sessionStorage](https://uk.javascript.info/localstorage)

[Cookies, sessionStorage, localStorage: у чому різниця](https://sneakbug8.com/cookies-js-storages/)  Може знадобитись VPN