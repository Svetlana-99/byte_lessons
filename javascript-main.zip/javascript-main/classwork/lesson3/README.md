#### Взаємодія з користувачем

1. [Взаємодія з користувачем](https://uk.javascript.info/alert-prompt-confirm).
2. Детально про: 
- [prompt()](https://developer.mozilla.org/ru/docs/Web/API/Window/prompt)
- [alert()](https://developer.mozilla.org/ru/docs/Web/API/Window/alert)
- [confirm()](https://developer.mozilla.org/ru/docs/Web/API/Window/confirm)


#### Оператори

1. [Вирази та оператори, детальна стаття](https://developer.mozilla.org/ru/docs/Web/JavaScript/Guide/Expressions_and_Operators)
2. [Логічні оператори](https://uk.javascript.info/logical-operators)
3. [Базові та математичні оператори](https://uk.javascript.info/operators)
4. [Оператори порівняння](https://uk.javascript.info/comparison)

#### Умовні опертори та умовне розгалуження

1. Операторы 
- [if...else](https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Statements/if...else)
- [Тернарний оператор](https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Operators/Conditional_Operator)
- [switch - case (1)](https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Statements/switch)
- [switch - case (2)](https://uk.javascript.info/switch)

2. [Статття про умовні конструкції](https://developer.mozilla.org/ru/docs/Learn/JavaScript/Building_blocks/conditionals)
3. [Ща статья про розгалуження і умовні конструкції](https://uk.javascript.info/ifelse)

