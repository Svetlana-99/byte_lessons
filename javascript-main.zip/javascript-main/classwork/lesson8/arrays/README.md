#### Массиви

1. [Масиви на MDN. Тут є хороші практичні завдання!](https://developer.mozilla.org/ru/docs/Learn/JavaScript/First_steps/Arrays)
2. [Про масиви на Learn.js](https://uk.javascript.info/array)


