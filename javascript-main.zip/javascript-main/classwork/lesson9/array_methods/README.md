#### Методи масивів

1. [15 методів роботи з масивами в JavaScript, котрі необхідно знати](https://habr.com/ru/company/plarium/blog/483958/) Може знадобитись VPN
2. [Ще стаття про методи масивів](https://medium.com/webbdev/js-5e1519c6fb07)
3. [І ще одна стаття про методи з прикладами використання](https://habr.com/ru/company/plarium/blog/446902/) Може знадобитись VPN
3. [Методи масивів. Learn.js](https://uk.javascript.info/array-methods)
4. [Глобальний об'єкт Array](https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Global_Objects/Array)
Список методів перелічено в меню зліва. По кожному з нихє детальна документація з прикладами.

