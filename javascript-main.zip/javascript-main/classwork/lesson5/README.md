#### Цикли

1. [Цикли в JavaScript](https://uk.javascript.info/while-for)
2. [Все про цикли, детальний аналіз](https://developer.mozilla.org/ru/docs/Learn/JavaScript/Building_blocks/Looping_code)
