#### Функції

1. [Функції (основи)](https://uk.javascript.info/function-basics)
2. [Все про функції(advanced матеріал)](https://developer.mozilla.org/ru/docs/Web/JavaScript/Guide/Functions)
3. [Ще стаття про функції в JavaScript](https://habr.com/en/company/ruvds/blog/430382/) Може знадобитися VPN.
4. [Параметри (аргументи) функцій за замовчанням](https://developer.mozilla.org/ru/docs/Web/JavaScript/Reference/Functions/Default_parameters)


