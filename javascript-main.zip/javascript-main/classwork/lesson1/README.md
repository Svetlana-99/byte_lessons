## Intro

Джерела інформації: 
1. [MDN Web Docs - документація JavaScript та веб-технологій](https://developer.mozilla.org/en-US/)
2. [Learn Javascript - підручник JavaScript(Pекомендується проходити парадельно з курсом)](https://uk.javascript.info/)
3. [StackOverflow](https://stackoverflow.com/)
4. [Medium - статті та навчальні матеріали](https://medium.com)
5. [Habr - ресурс для программістів і людей, що цікаляться IT](https://habr.com/ru/). Може потребувати VPN.

Додаткові практичні завдання. Рекомендуємо проходити разом з курсом.
1. [Edabit Challenges](https://edabit.com/challenges)
2. [freeCodeCamp](https://www.freecodecamp.org/)

Загальне: 

1. [Що таке JS. Advanced матеріал](https://developer.mozilla.org/ru/docs/Learn/JavaScript/First_steps/What_is_JavaScript)
2. [Що таке JS. Простий матеріал](https://uk.javascript.info/intro)
3. [Що вміє JavaScript? (Спойлер: Так, не тільки сайти)](https://medium.com/@lucyhackwrench/%D1%87%D1%82%D0%BE-%D1%81%D0%B5%D0%B3%D0%BE%D0%B4%D0%BD%D1%8F-%D1%83%D0%BC%D0%B5%D0%B5%D1%82-javascript-7bc85338c56e)


## Git
1. [Инструкція по встановленню для кожної операційної системи](https://git-scm.com/book/uk/v2/%D0%92%D1%81%D1%82%D1%83%D0%BF-%D0%9F%D0%BE%D1%87%D0%B0%D1%82%D0%BA%D0%BE%D0%B2%D0%B5-%D0%BD%D0%B0%D0%BB%D0%B0%D1%88%D1%82%D1%83%D0%B2%D0%B0%D0%BD%D0%BD%D1%8F-Git)
2. [Що таке Git?](https://git-scm.com/book/uk/v2/%D0%92%D1%81%D1%82%D1%83%D0%BF-%D0%9E%D1%81%D0%BD%D0%BE%D0%B2%D0%B8-Git)
3. [Як додати пункт контекстного меню для відкриття терміналу на Mac OS](https://ladedu.com/how-to-open-a-terminal-window-at-any-folder-from-finder-in-macos/)
4. [Дуже корисний практичний курс по git](https://githowto.com/uk)
В цьому матеріалі розглядаються просунуті теми по git. Рекомендуємо ознайомитись і з ними.
5. [Як використовувати Git в VS Code](https://code.visualstudio.com/Docs/editor/versioncontrol)
6. [Що таке термінал ?](https://samoedd.com/soft/terminal-unix)