console.log('Hello world!')

console.log(1);

console.log(2);

let test = 'Hi!'
console.log(test);

console.log(`test`, test)