#### Змінні

1. [Змінні, синтаксис та основи](https://uk.javascript.info/variables).
2. [Більше про let и const, області видимості змінних](https://learn.javascript.ru/let-const)
3. [Ще про змінні на MDN](https://developer.mozilla.org/ru/docs/Learn/JavaScript/First_steps/Variables)

#### Типи даних

1. [Стаття про типи даних в мовах програмування](https://habr.com/ru/post/161205/) Може знадобитись VPN.
2. [Типи даних](https://uk.javascript.info/types)
3. [Ще типи даних в JavaScript. Більш обширний та глибокий матеріал.](https://developer.mozilla.org/ru/docs/Web/JavaScript/Data_structures)
4. [Перетворення типів даних](https://uk.javascript.info/type-conversions)
5. [Cтаття про перетворення типів даних з прикладами](https://www.programiz.com/javascript/type-conversion)


Додатково: 
- [Список зарезервованих слів в JavaScript](https://www.w3schools.com/JavaScript/JavaScript_reserved.asp)

Дві наступні статті иістять матеріал про сутності js, що будуть вивчені далі в курсу. Прочитайте початок про змінні та збережіть собі посилання на потім.
- [Угода іменування змінних](https://www.robinwieruch.de/javascript-naming-conventions/#:~:text=There%20are%20no%20special%20naming,UPPERCASE%20if%20it%20is%20immutable.)
- [Базовий JS Style Guide](https://www.w3schools.com/js/js_conventions.asp)
