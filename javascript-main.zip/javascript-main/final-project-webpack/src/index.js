import { a } from "./test.js";
import './styles/style.css'

console.log("hello world!!!", 30);
